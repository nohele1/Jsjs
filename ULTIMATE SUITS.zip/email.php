<?php
$emailku = 's@gmail.com'; // GANTI EMAIL KAMU DISINI
?>